var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/indikator/route.js")
R.c("server/chunks/[root-of-the-server]__11..8zh._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/[root-of-the-server]__0bmmc8z._.js")
R.c("server/chunks/_next-internal_server_app_api_indikator_route_actions_0ozoz32.js")
R.m(50088)
module.exports=R.m(50088).exports
