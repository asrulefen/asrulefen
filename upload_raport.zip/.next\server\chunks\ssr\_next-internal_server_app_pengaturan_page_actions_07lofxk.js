module.exports=[82967,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_pengaturan_page_actions_07lofxk.js.map