module.exports=[87442,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_indikator_%5Bid%5D_route_actions_0c-3_1w.js.map