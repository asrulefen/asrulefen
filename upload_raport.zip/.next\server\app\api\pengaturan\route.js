var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/pengaturan/route.js")
R.c("server/chunks/[root-of-the-server]__0mreoi9._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_pengaturan_route_actions_040_-3v.js")
R.m(25196)
module.exports=R.m(25196).exports
