module.exports=[18622,(e,a,t)=>{a.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,a,t)=>{a.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,a,t)=>{a.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,a,t)=>{a.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,a,t)=>{a.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},14747,(e,a,t)=>{a.exports=e.x("path",()=>require("path"))},93695,(e,a,t)=>{a.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},85148,(e,a,t)=>{a.exports=e.x("better-sqlite3-90e2652d1716b047",()=>require("better-sqlite3-90e2652d1716b047"))},43793,e=>{"use strict";var a=e.i(85148);let t=e.i(14747).default.join(process.cwd(),"raport.db"),n=e.g._db||new a.default(t,{verbose:console.log});if(n.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS siswa (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nama_lengkap TEXT NOT NULL,
    nama_panggilan TEXT,
    nisn TEXT,
    kelompok TEXT DEFAULT 'A',
    jenis_kelamin TEXT,
    tempat_lahir TEXT,
    tanggal_lahir TEXT,
    agama TEXT,
    anak_ke TEXT,
    nama_ayah TEXT,
    nama_ibu TEXT,
    pekerjaan_ayah TEXT,
    pekerjaan_ibu TEXT,
    alamat TEXT,
    telepon TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS pengaturan (
    key TEXT PRIMARY KEY,
    value TEXT
  );

  CREATE TABLE IF NOT EXISTS indikator (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kategori TEXT NOT NULL, -- AGAMA, JATI_DIRI, LITERASI, PROJEK
    deskripsi TEXT NOT NULL,
    urutan INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS raport (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    siswa_id INTEGER,
    semester TEXT NOT NULL, -- I / 2025-2026
    tinggi_badan TEXT,
    berat_badan TEXT,
    sakit TEXT DEFAULT '0',
    izin TEXT DEFAULT '0',
    tanpa_keterangan TEXT DEFAULT '0',
    
    -- Teks Narasi AI
    teks_agama TEXT,
    teks_jati_diri TEXT,
    teks_literasi TEXT,
    teks_projek TEXT,
    refleksi_guru TEXT,

    -- Foto (Disimpan sebagai path lokal atau base64 jika kecil)
    foto_agama_1 TEXT, foto_agama_2 TEXT, foto_agama_3 TEXT,
    foto_jati_diri_1 TEXT, foto_jati_diri_2 TEXT, foto_jati_diri_3 TEXT,
    foto_literasi_1 TEXT, foto_literasi_2 TEXT, foto_literasi_3 TEXT,
    foto_projek_1 TEXT, foto_projek_2 TEXT, foto_projek_3 TEXT,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(siswa_id) REFERENCES siswa(id)
  );

  CREATE TABLE IF NOT EXISTS nilai_indikator (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    raport_id INTEGER,
    indikator_id INTEGER,
    nilai TEXT, -- Belum Muncul, Muncul Sebagian Besar, Muncul, Berkembang Sangat Baik
    FOREIGN KEY(raport_id) REFERENCES raport(id) ON DELETE CASCADE,
    FOREIGN KEY(indikator_id) REFERENCES indikator(id)
  );
`),0===n.prepare("SELECT COUNT(*) as count FROM indikator").get().count){let e=n.prepare("INSERT INTO indikator (kategori, deskripsi, urutan) VALUES (?, ?, ?)"),a=[["AGAMA","Mengucap kalimat Thoyyibah",1],["AGAMA","Melaksanakan atau mempraktekkan ibadah sehari-hari (Praktek sholat dhuha)",2],["AGAMA","Berdoa sebelum dan sesudah melaksanakan kegiatan dengan tertib",3],["AGAMA","Mengembalikan benda yang tidak miliknya",4],["AGAMA","Mengucap permisi jika mau lewat",5],["JATI_DIRI","Melakukan permainan fisik dengan teratur",1],["JATI_DIRI","Menggunakan alat tulis atau memegang pensil dengan benar",2],["JATI_DIRI","Meniru gerakan senam fantasi",3],["JATI_DIRI","Berdiri dengan tumit, berdiri dengan satu kaki dengan seimbang",4],["JATI_DIRI","Sabar menunggu giliran",5],["JATI_DIRI","Mau ditinggal ibu tanpa menangis",6],["LITERASI","Melakukan 2-3 perintah sederhana",1],["LITERASI","Menyebut Kembali 3-4 kata yang baru didengarnya",2],["LITERASI","Menyebut dan menunjukkan benda-benda yang berbentuk geometri",3],["LITERASI","Menunjukkan urutan benda untuk bilangan 1-10",4],["LITERASI","Melukis dengan jari",5],["LITERASI","Menyebutkan benda di sekitar sesuai dengan fungsinya",6],["PROJEK","Mengenal lingkungan serta memupuk kepedulian terhadap alam",1],["PROJEK","Melakukan kegiatan praktik secara bergotong royong",2],["PROJEK","Menyiapkan bahan-bahan menanam biji jagung dengan sistem hidroponik",3],["PROJEK","Menunjukkan antusiasme yang luar biasa dan mengisi media tanam dengan rapi",4],["PROJEK","Tekun memasukkan benih dan bertanggung jawab menyiram tanaman",5],["PROJEK","Menceritakan perubahan jagung dari tunas hingga tumbuh daun",6]];n.transaction(()=>{for(let t of a)e.run(t[0],t[1],t[2])})()}n.prepare("SELECT value FROM pengaturan WHERE key = 'gemini_api_key'").get()||n.prepare("INSERT INTO pengaturan (key, value) VALUES ('gemini_api_key', 'AIzaSyBdyaDHSyeiVtW0DC69TOPwDK58IF8HomU')").run();let r=(e,a,t)=>{try{n.exec(`ALTER TABLE ${e} ADD COLUMN ${a} TEXT DEFAULT '${t}'`)}catch(e){}};r("siswa","desa",""),r("siswa","kecamatan",""),r("siswa","kabupaten","Tuban"),r("siswa","provinsi","Jawa Timur"),r("siswa","nipd",""),r("siswa","user_id","1"),r("indikator","user_id","1"),e.s(["default",0,n])},59889,e=>{"use strict";var a=e.i(47909),t=e.i(74017),n=e.i(96250),r=e.i(59756),i=e.i(61916),s=e.i(74677),o=e.i(69741),l=e.i(16795),u=e.i(87718),d=e.i(95169),p=e.i(47587),T=e.i(66012),E=e.i(70101),g=e.i(26937),k=e.i(10372),c=e.i(93695);e.i(52474);var m=e.i(220),R=e.i(89171),_=e.i(43793);async function A(e){try{let a=await e.json();if(!Array.isArray(a)||0===a.length)return R.NextResponse.json({error:"Data tidak valid atau kosong"},{status:400});let t=_.default.prepare(`
      INSERT INTO siswa (
        nama_lengkap, nama_panggilan, nisn, nipd, kelompok, jenis_kelamin, tempat_lahir,
        tanggal_lahir, agama, anak_ke, nama_ayah, nama_ibu, pekerjaan_ayah, pekerjaan_ibu,
        alamat, desa, kecamatan, kabupaten, provinsi, telepon
      ) VALUES (
        @nama_lengkap, @nama_panggilan, @nisn, @nipd, @kelompok, @jenis_kelamin, @tempat_lahir,
        @tanggal_lahir, @agama, @anak_ke, @nama_ayah, @nama_ibu, @pekerjaan_ayah, @pekerjaan_ibu,
        @alamat, @telepon
      )
    `),n=0;return _.default.transaction(()=>{for(let e of a)e.nama_lengkap&&(t.run({nama_lengkap:e.nama_lengkap||"",nama_panggilan:e.nama_panggilan||"",nisn:e.nisn||"",nipd:e.nipd||e.NIPD||"",kelompok:e.kelompok||"A",jenis_kelamin:e.jenis_kelamin||"Laki-laki",tempat_lahir:e.tempat_lahir||"",tanggal_lahir:e.tanggal_lahir||"",agama:e.agama||"Islam",anak_ke:e.anak_ke||"1",nama_ayah:e.nama_ayah||"",nama_ibu:e.nama_ibu||"",pekerjaan_ayah:e.pekerjaan_ayah||"",pekerjaan_ibu:e.pekerjaan_ibu||"",alamat:e.alamat||"",telepon:e.telepon||""}),n++)})(),R.NextResponse.json({success:!0,count:n})}catch(e){return console.error("Bulk Import Error:",e),R.NextResponse.json({error:"Gagal mengimpor data siswa"},{status:500})}}e.s(["POST",0,A],41626);var h=e.i(41626);let I=new a.AppRouteRouteModule({definition:{kind:t.RouteKind.APP_ROUTE,page:"/api/siswa/import/route",pathname:"/api/siswa/import",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/src/app/api/siswa/import/route.ts",nextConfigOutput:"standalone",userland:h,...{}}),{workAsyncStorage:b,workUnitAsyncStorage:N,serverHooks:x}=I;async function y(e,a,n){n.requestMeta&&(0,r.setRequestMeta)(e,n.requestMeta),I.isDev&&(0,r.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let R="/api/siswa/import/route";R=R.replace(/\/index$/,"")||"/";let _=await I.prepare(e,a,{srcPage:R,multiZoneDraftMode:!1});if(!_)return a.statusCode=400,a.end("Bad Request"),null==n.waitUntil||n.waitUntil.call(n,Promise.resolve()),null;let{buildId:A,deploymentId:h,params:b,nextConfig:N,parsedUrl:x,isDraftMode:y,prerenderManifest:f,routerServerContext:v,isOnDemandRevalidate:w,revalidateOnlyGenerated:M,resolvedPathname:S,clientReferenceManifest:C,serverActionsManifest:O}=_,X=(0,o.normalizeAppPath)(R),j=!!(f.dynamicRoutes[X]||f.routes[S]),L=async()=>((null==v?void 0:v.render404)?await v.render404(e,a,x,!1):a.end("This page could not be found"),null);if(j&&!y){let e=!!f.routes[S],a=f.dynamicRoutes[X];if(a&&!1===a.fallback&&!e){if(N.adapterPath)return await L();throw new c.NoFallbackError}}let U=null;!j||I.isDev||y||(U="/index"===(U=S)?"/":U);let P=!0===I.isDev||!j,D=j&&!P;O&&C&&(0,s.setManifestsSingleton)({page:R,clientReferenceManifest:C,serverActionsManifest:O});let F=e.method||"GET",q=(0,i.getTracer)(),K=q.getActiveScopeSpan(),G=!!(null==v?void 0:v.isWrappedByNextServer),B=!!(0,r.getRequestMeta)(e,"minimalMode"),H=(0,r.getRequestMeta)(e,"incrementalCache")||await I.getIncrementalCache(e,N,f,B);null==H||H.resetRequestCache(),globalThis.__incrementalCache=H;let J={params:b,previewProps:f.preview,renderOpts:{experimental:{authInterrupts:!!N.experimental.authInterrupts},cacheComponents:!!N.cacheComponents,supportsDynamicResponse:P,incrementalCache:H,cacheLifeProfiles:N.cacheLife,waitUntil:n.waitUntil,onClose:e=>{a.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(a,t,n,r)=>I.onRequestError(e,a,n,r,v)},sharedContext:{buildId:A,deploymentId:h}},Y=new l.NodeNextRequest(e),$=new l.NodeNextResponse(a),V=u.NextRequestAdapter.fromNodeNextRequest(Y,(0,u.signalFromNodeResponse)(a));try{let r,s=async e=>I.handle(V,J).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":a.statusCode,"next.rsc":!1});let t=q.getRootSpanAttributes();if(!t)return;if(t.get("next.span_type")!==d.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${t.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let n=t.get("next.route");if(n){let a=`${F} ${n}`;e.setAttributes({"next.route":n,"http.route":n,"next.span_name":a}),e.updateName(a),r&&r!==e&&(r.setAttribute("http.route",n),r.updateName(a))}else e.updateName(`${F} ${R}`)}),o=async r=>{var i,o;let l=async({previousCacheEntry:t})=>{try{if(!B&&w&&M&&!t)return a.statusCode=404,a.setHeader("x-nextjs-cache","REVALIDATED"),a.end("This page could not be found"),null;let i=await s(r);e.fetchMetrics=J.renderOpts.fetchMetrics;let o=J.renderOpts.pendingWaitUntil;o&&n.waitUntil&&(n.waitUntil(o),o=void 0);let l=J.renderOpts.collectedTags;if(!j)return await (0,T.sendResponse)(Y,$,i,J.renderOpts.pendingWaitUntil),null;{let e=await i.blob(),a=(0,E.toNodeOutgoingHttpHeaders)(i.headers);l&&(a[k.NEXT_CACHE_TAGS_HEADER]=l),!a["content-type"]&&e.type&&(a["content-type"]=e.type);let t=void 0!==J.renderOpts.collectedRevalidate&&!(J.renderOpts.collectedRevalidate>=k.INFINITE_CACHE)&&J.renderOpts.collectedRevalidate,n=void 0===J.renderOpts.collectedExpire||J.renderOpts.collectedExpire>=k.INFINITE_CACHE?void 0:J.renderOpts.collectedExpire;return{value:{kind:m.CachedRouteKind.APP_ROUTE,status:i.status,body:Buffer.from(await e.arrayBuffer()),headers:a},cacheControl:{revalidate:t,expire:n}}}}catch(a){throw(null==t?void 0:t.isStale)&&await I.onRequestError(e,a,{routerKind:"App Router",routePath:R,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:D,isOnDemandRevalidate:w})},!1,v),a}},u=await I.handleResponse({req:e,nextConfig:N,cacheKey:U,routeKind:t.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:f,isRoutePPREnabled:!1,isOnDemandRevalidate:w,revalidateOnlyGenerated:M,responseGenerator:l,waitUntil:n.waitUntil,isMinimalMode:B});if(!j)return null;if((null==u||null==(i=u.value)?void 0:i.kind)!==m.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==u||null==(o=u.value)?void 0:o.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});B||a.setHeader("x-nextjs-cache",w?"REVALIDATED":u.isMiss?"MISS":u.isStale?"STALE":"HIT"),y&&a.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let d=(0,E.fromNodeOutgoingHttpHeaders)(u.value.headers);return B&&j||d.delete(k.NEXT_CACHE_TAGS_HEADER),!u.cacheControl||a.getHeader("Cache-Control")||d.get("Cache-Control")||d.set("Cache-Control",(0,g.getCacheControlHeader)(u.cacheControl)),await (0,T.sendResponse)(Y,$,new Response(u.value.body,{headers:d,status:u.value.status||200})),null};G&&K?await o(K):(r=q.getActiveScopeSpan(),await q.withPropagatedContext(e.headers,()=>q.trace(d.BaseServerSpan.handleRequest,{spanName:`${F} ${R}`,kind:i.SpanKind.SERVER,attributes:{"http.method":F,"http.target":e.url}},o),void 0,!G))}catch(a){if(a instanceof c.NoFallbackError||await I.onRequestError(e,a,{routerKind:"App Router",routePath:X,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:D,isOnDemandRevalidate:w})},!1,v),j)throw a;return await (0,T.sendResponse)(Y,$,new Response(null,{status:500})),null}}e.s(["handler",0,y,"patchFetch",0,function(){return(0,n.patchFetch)({workAsyncStorage:b,workUnitAsyncStorage:N})},"routeModule",0,I,"serverHooks",0,x,"workAsyncStorage",0,b,"workUnitAsyncStorage",0,N],59889)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0h0dybn._.js.map