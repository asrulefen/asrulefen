module.exports=[34135,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_generate-docx_route_actions_0q41hru.js.map