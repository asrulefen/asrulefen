var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/siswa/import/route.js")
R.c("server/chunks/[root-of-the-server]__0h0dybn._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_siswa_import_route_actions_04i4oy6.js")
R.m(59889)
module.exports=R.m(59889).exports
