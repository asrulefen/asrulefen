module.exports=[82372,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_indikator_page_actions_0.hq~iw.js.map