module.exports=[43920,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_upload-template_route_actions_07vb143.js.map