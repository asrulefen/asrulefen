var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[root-of-the-server]__0xfesnn._.js")
R.c("server/chunks/node_modules_bcryptjs_index_0bjz0ul.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/[root-of-the-server]__0bmmc8z._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_[___nextauth]_route_actions_04_0y9h.js")
R.m(3413)
module.exports=R.m(3413).exports
