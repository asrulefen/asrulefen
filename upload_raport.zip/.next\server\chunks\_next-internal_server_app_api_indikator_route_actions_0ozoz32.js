module.exports=[65944,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_indikator_route_actions_0ozoz32.js.map