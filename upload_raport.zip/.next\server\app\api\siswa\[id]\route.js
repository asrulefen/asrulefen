var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/siswa/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0vccdbz._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/[root-of-the-server]__0bmmc8z._.js")
R.c("server/chunks/_next-internal_server_app_api_siswa_[id]_route_actions_020ouxc.js")
R.m(51464)
module.exports=R.m(51464).exports
