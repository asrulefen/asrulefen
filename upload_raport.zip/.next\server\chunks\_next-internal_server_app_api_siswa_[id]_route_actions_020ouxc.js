module.exports=[56436,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_siswa_%5Bid%5D_route_actions_020ouxc.js.map