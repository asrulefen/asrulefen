var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/upload-template/route.js")
R.c("server/chunks/[root-of-the-server]__077j32_._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/[root-of-the-server]__0.2jkyy._.js")
R.c("server/chunks/_next-internal_server_app_api_upload-template_route_actions_07vb143.js")
R.m(81136)
module.exports=R.m(81136).exports
