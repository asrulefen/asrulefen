1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/0ms7ed6dn2p0z.js","/_next/static/chunks/0nt2g9v62pibn.js","/_next/static/chunks/12x4y2.3s07by.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
3:I[37457,["/_next/static/chunks/0ms7ed6dn2p0z.js","/_next/static/chunks/0nt2g9v62pibn.js","/_next/static/chunks/12x4y2.3s07by.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"ubxh6GmhCg8jh_X502zt-"}
