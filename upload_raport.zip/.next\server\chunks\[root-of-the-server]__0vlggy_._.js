module.exports=[18622,(e,a,t)=>{a.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,a,t)=>{a.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,a,t)=>{a.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,a,t)=>{a.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,a,t)=>{a.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},24361,(e,a,t)=>{a.exports=e.x("util",()=>require("util"))},14747,(e,a,t)=>{a.exports=e.x("path",()=>require("path"))},93695,(e,a,t)=>{a.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},85148,(e,a,t)=>{a.exports=e.x("better-sqlite3-90e2652d1716b047",()=>require("better-sqlite3-90e2652d1716b047"))},43793,e=>{"use strict";var a=e.i(85148);let t=e.i(14747).default.join(process.cwd(),"raport.db"),n=e.g._db||new a.default(t,{verbose:console.log});if(n.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS siswa (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nama_lengkap TEXT NOT NULL,
    nama_panggilan TEXT,
    nisn TEXT,
    kelompok TEXT DEFAULT 'A',
    jenis_kelamin TEXT,
    tempat_lahir TEXT,
    tanggal_lahir TEXT,
    agama TEXT,
    anak_ke TEXT,
    nama_ayah TEXT,
    nama_ibu TEXT,
    pekerjaan_ayah TEXT,
    pekerjaan_ibu TEXT,
    alamat TEXT,
    telepon TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS pengaturan (
    key TEXT PRIMARY KEY,
    value TEXT
  );

  CREATE TABLE IF NOT EXISTS indikator (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kategori TEXT NOT NULL, -- AGAMA, JATI_DIRI, LITERASI, PROJEK
    deskripsi TEXT NOT NULL,
    urutan INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS raport (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    siswa_id INTEGER,
    semester TEXT NOT NULL, -- I / 2025-2026
    tinggi_badan TEXT,
    berat_badan TEXT,
    sakit TEXT DEFAULT '0',
    izin TEXT DEFAULT '0',
    tanpa_keterangan TEXT DEFAULT '0',
    
    -- Teks Narasi AI
    teks_agama TEXT,
    teks_jati_diri TEXT,
    teks_literasi TEXT,
    teks_projek TEXT,
    refleksi_guru TEXT,

    -- Foto (Disimpan sebagai path lokal atau base64 jika kecil)
    foto_agama_1 TEXT, foto_agama_2 TEXT, foto_agama_3 TEXT,
    foto_jati_diri_1 TEXT, foto_jati_diri_2 TEXT, foto_jati_diri_3 TEXT,
    foto_literasi_1 TEXT, foto_literasi_2 TEXT, foto_literasi_3 TEXT,
    foto_projek_1 TEXT, foto_projek_2 TEXT, foto_projek_3 TEXT,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(siswa_id) REFERENCES siswa(id)
  );

  CREATE TABLE IF NOT EXISTS nilai_indikator (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    raport_id INTEGER,
    indikator_id INTEGER,
    nilai TEXT, -- Belum Muncul, Muncul Sebagian Besar, Muncul, Berkembang Sangat Baik
    FOREIGN KEY(raport_id) REFERENCES raport(id) ON DELETE CASCADE,
    FOREIGN KEY(indikator_id) REFERENCES indikator(id)
  );
`),0===n.prepare("SELECT COUNT(*) as count FROM indikator").get().count){let e=n.prepare("INSERT INTO indikator (kategori, deskripsi, urutan) VALUES (?, ?, ?)"),a=[["AGAMA","Mengucap kalimat Thoyyibah",1],["AGAMA","Melaksanakan atau mempraktekkan ibadah sehari-hari (Praktek sholat dhuha)",2],["AGAMA","Berdoa sebelum dan sesudah melaksanakan kegiatan dengan tertib",3],["AGAMA","Mengembalikan benda yang tidak miliknya",4],["AGAMA","Mengucap permisi jika mau lewat",5],["JATI_DIRI","Melakukan permainan fisik dengan teratur",1],["JATI_DIRI","Menggunakan alat tulis atau memegang pensil dengan benar",2],["JATI_DIRI","Meniru gerakan senam fantasi",3],["JATI_DIRI","Berdiri dengan tumit, berdiri dengan satu kaki dengan seimbang",4],["JATI_DIRI","Sabar menunggu giliran",5],["JATI_DIRI","Mau ditinggal ibu tanpa menangis",6],["LITERASI","Melakukan 2-3 perintah sederhana",1],["LITERASI","Menyebut Kembali 3-4 kata yang baru didengarnya",2],["LITERASI","Menyebut dan menunjukkan benda-benda yang berbentuk geometri",3],["LITERASI","Menunjukkan urutan benda untuk bilangan 1-10",4],["LITERASI","Melukis dengan jari",5],["LITERASI","Menyebutkan benda di sekitar sesuai dengan fungsinya",6],["PROJEK","Mengenal lingkungan serta memupuk kepedulian terhadap alam",1],["PROJEK","Melakukan kegiatan praktik secara bergotong royong",2],["PROJEK","Menyiapkan bahan-bahan menanam biji jagung dengan sistem hidroponik",3],["PROJEK","Menunjukkan antusiasme yang luar biasa dan mengisi media tanam dengan rapi",4],["PROJEK","Tekun memasukkan benih dan bertanggung jawab menyiram tanaman",5],["PROJEK","Menceritakan perubahan jagung dari tunas hingga tumbuh daun",6]];n.transaction(()=>{for(let t of a)e.run(t[0],t[1],t[2])})()}n.prepare("SELECT value FROM pengaturan WHERE key = 'gemini_api_key'").get()||n.prepare("INSERT INTO pengaturan (key, value) VALUES ('gemini_api_key', 'AIzaSyBdyaDHSyeiVtW0DC69TOPwDK58IF8HomU')").run();let r=(e,a,t)=>{try{n.exec(`ALTER TABLE ${e} ADD COLUMN ${a} TEXT DEFAULT '${t}'`)}catch(e){}};r("siswa","desa",""),r("siswa","kecamatan",""),r("siswa","kabupaten","Tuban"),r("siswa","provinsi","Jawa Timur"),r("siswa","nipd",""),r("siswa","user_id","1"),r("indikator","user_id","1"),e.s(["default",0,n])},54799,(e,a,t)=>{a.exports=e.x("crypto",()=>require("crypto"))},92260,e=>{"use strict";var a=e.i(47909),t=e.i(74017),n=e.i(96250),r=e.i(59756),i=e.i(61916),s=e.i(74677),o=e.i(69741),l=e.i(16795),u=e.i(87718),d=e.i(95169),p=e.i(47587),E=e.i(66012),T=e.i(70101),c=e.i(26937),R=e.i(10372),g=e.i(93695);e.i(52474);var k=e.i(220),m=e.i(89171),_=e.i(43793),A=e.i(23667);async function h(){try{let e=await (0,A.getServerSession)();if(!e?.user?.email)return m.NextResponse.json({error:"Unauthorized"},{status:401});let a=_.default.prepare("SELECT id FROM users WHERE email = ?").get(e.user.email);if(!a)return m.NextResponse.json({error:"Unauthorized"},{status:401});let t=_.default.prepare("SELECT * FROM siswa WHERE user_id = ? ORDER BY nama_lengkap ASC").all(a.id);return m.NextResponse.json(t)}catch(e){return m.NextResponse.json({error:"Failed to fetch siswa"},{status:500})}}async function I(e){try{let a=await (0,A.getServerSession)();if(!a?.user?.email)return m.NextResponse.json({error:"Unauthorized"},{status:401});let t=_.default.prepare("SELECT id FROM users WHERE email = ?").get(a.user.email);if(!t)return m.NextResponse.json({error:"Unauthorized"},{status:401});let n=await e.json();n.user_id=t.id;let r=_.default.prepare(`
      INSERT INTO siswa (
        user_id, nama_lengkap, nama_panggilan, nisn, nipd, kelompok, jenis_kelamin, tempat_lahir,
        tanggal_lahir, agama, anak_ke, nama_ayah, nama_ibu, pekerjaan_ayah, pekerjaan_ibu,
        alamat, desa, kecamatan, kabupaten, provinsi, telepon
      ) VALUES (
        @user_id, @nama_lengkap, @nama_panggilan, @nisn, @nipd, @kelompok, @jenis_kelamin, @tempat_lahir,
        @tanggal_lahir, @agama, @anak_ke, @nama_ayah, @nama_ibu, @pekerjaan_ayah, @pekerjaan_ibu,
        @alamat, @desa, @kecamatan, @kabupaten, @provinsi, @telepon
      )
    `).run(n);return m.NextResponse.json({id:r.lastInsertRowid})}catch(e){return console.error(e),m.NextResponse.json({error:"Failed to create siswa"},{status:500})}}e.s(["GET",0,h,"POST",0,I],68118);var N=e.i(68118);let b=new a.AppRouteRouteModule({definition:{kind:t.RouteKind.APP_ROUTE,page:"/api/siswa/route",pathname:"/api/siswa",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/src/app/api/siswa/route.ts",nextConfigOutput:"standalone",userland:N,...{}}),{workAsyncStorage:x,workUnitAsyncStorage:f,serverHooks:w}=b;async function y(e,a,n){n.requestMeta&&(0,r.setRequestMeta)(e,n.requestMeta),b.isDev&&(0,r.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let m="/api/siswa/route";m=m.replace(/\/index$/,"")||"/";let _=await b.prepare(e,a,{srcPage:m,multiZoneDraftMode:!1});if(!_)return a.statusCode=400,a.end("Bad Request"),null==n.waitUntil||n.waitUntil.call(n,Promise.resolve()),null;let{buildId:A,deploymentId:h,params:I,nextConfig:N,parsedUrl:x,isDraftMode:f,prerenderManifest:w,routerServerContext:y,isOnDemandRevalidate:S,revalidateOnlyGenerated:v,resolvedPathname:M,clientReferenceManifest:C,serverActionsManifest:O}=_,X=(0,o.normalizeAppPath)(m),j=!!(w.dynamicRoutes[X]||w.routes[M]),L=async()=>((null==y?void 0:y.render404)?await y.render404(e,a,x,!1):a.end("This page could not be found"),null);if(j&&!f){let e=!!w.routes[M],a=w.dynamicRoutes[X];if(a&&!1===a.fallback&&!e){if(N.adapterPath)return await L();throw new g.NoFallbackError}}let U=null;!j||b.isDev||f||(U="/index"===(U=M)?"/":U);let P=!0===b.isDev||!j,D=j&&!P;O&&C&&(0,s.setManifestsSingleton)({page:m,clientReferenceManifest:C,serverActionsManifest:O});let F=e.method||"GET",q=(0,i.getTracer)(),K=q.getActiveScopeSpan(),H=!!(null==y?void 0:y.isWrappedByNextServer),G=!!(0,r.getRequestMeta)(e,"minimalMode"),B=(0,r.getRequestMeta)(e,"incrementalCache")||await b.getIncrementalCache(e,N,w,G);null==B||B.resetRequestCache(),globalThis.__incrementalCache=B;let Y={params:I,previewProps:w.preview,renderOpts:{experimental:{authInterrupts:!!N.experimental.authInterrupts},cacheComponents:!!N.cacheComponents,supportsDynamicResponse:P,incrementalCache:B,cacheLifeProfiles:N.cacheLife,waitUntil:n.waitUntil,onClose:e=>{a.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(a,t,n,r)=>b.onRequestError(e,a,n,r,y)},sharedContext:{buildId:A,deploymentId:h}},J=new l.NodeNextRequest(e),$=new l.NodeNextResponse(a),W=u.NextRequestAdapter.fromNodeNextRequest(J,(0,u.signalFromNodeResponse)(a));try{let r,s=async e=>b.handle(W,Y).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":a.statusCode,"next.rsc":!1});let t=q.getRootSpanAttributes();if(!t)return;if(t.get("next.span_type")!==d.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${t.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let n=t.get("next.route");if(n){let a=`${F} ${n}`;e.setAttributes({"next.route":n,"http.route":n,"next.span_name":a}),e.updateName(a),r&&r!==e&&(r.setAttribute("http.route",n),r.updateName(a))}else e.updateName(`${F} ${m}`)}),o=async r=>{var i,o;let l=async({previousCacheEntry:t})=>{try{if(!G&&S&&v&&!t)return a.statusCode=404,a.setHeader("x-nextjs-cache","REVALIDATED"),a.end("This page could not be found"),null;let i=await s(r);e.fetchMetrics=Y.renderOpts.fetchMetrics;let o=Y.renderOpts.pendingWaitUntil;o&&n.waitUntil&&(n.waitUntil(o),o=void 0);let l=Y.renderOpts.collectedTags;if(!j)return await (0,E.sendResponse)(J,$,i,Y.renderOpts.pendingWaitUntil),null;{let e=await i.blob(),a=(0,T.toNodeOutgoingHttpHeaders)(i.headers);l&&(a[R.NEXT_CACHE_TAGS_HEADER]=l),!a["content-type"]&&e.type&&(a["content-type"]=e.type);let t=void 0!==Y.renderOpts.collectedRevalidate&&!(Y.renderOpts.collectedRevalidate>=R.INFINITE_CACHE)&&Y.renderOpts.collectedRevalidate,n=void 0===Y.renderOpts.collectedExpire||Y.renderOpts.collectedExpire>=R.INFINITE_CACHE?void 0:Y.renderOpts.collectedExpire;return{value:{kind:k.CachedRouteKind.APP_ROUTE,status:i.status,body:Buffer.from(await e.arrayBuffer()),headers:a},cacheControl:{revalidate:t,expire:n}}}}catch(a){throw(null==t?void 0:t.isStale)&&await b.onRequestError(e,a,{routerKind:"App Router",routePath:m,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:D,isOnDemandRevalidate:S})},!1,y),a}},u=await b.handleResponse({req:e,nextConfig:N,cacheKey:U,routeKind:t.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:w,isRoutePPREnabled:!1,isOnDemandRevalidate:S,revalidateOnlyGenerated:v,responseGenerator:l,waitUntil:n.waitUntil,isMinimalMode:G});if(!j)return null;if((null==u||null==(i=u.value)?void 0:i.kind)!==k.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==u||null==(o=u.value)?void 0:o.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});G||a.setHeader("x-nextjs-cache",S?"REVALIDATED":u.isMiss?"MISS":u.isStale?"STALE":"HIT"),f&&a.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let d=(0,T.fromNodeOutgoingHttpHeaders)(u.value.headers);return G&&j||d.delete(R.NEXT_CACHE_TAGS_HEADER),!u.cacheControl||a.getHeader("Cache-Control")||d.get("Cache-Control")||d.set("Cache-Control",(0,c.getCacheControlHeader)(u.cacheControl)),await (0,E.sendResponse)(J,$,new Response(u.value.body,{headers:d,status:u.value.status||200})),null};H&&K?await o(K):(r=q.getActiveScopeSpan(),await q.withPropagatedContext(e.headers,()=>q.trace(d.BaseServerSpan.handleRequest,{spanName:`${F} ${m}`,kind:i.SpanKind.SERVER,attributes:{"http.method":F,"http.target":e.url}},o),void 0,!H))}catch(a){if(a instanceof g.NoFallbackError||await b.onRequestError(e,a,{routerKind:"App Router",routePath:X,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:D,isOnDemandRevalidate:S})},!1,y),j)throw a;return await (0,E.sendResponse)(J,$,new Response(null,{status:500})),null}}e.s(["handler",0,y,"patchFetch",0,function(){return(0,n.patchFetch)({workAsyncStorage:x,workUnitAsyncStorage:f})},"routeModule",0,b,"serverHooks",0,w,"workAsyncStorage",0,x,"workUnitAsyncStorage",0,f],92260)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0vlggy_._.js.map