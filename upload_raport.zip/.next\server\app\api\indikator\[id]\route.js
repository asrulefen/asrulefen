var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/indikator/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0~ykpk5._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/[root-of-the-server]__0bmmc8z._.js")
R.c("server/chunks/_next-internal_server_app_api_indikator_[id]_route_actions_0c-3_1w.js")
R.m(24378)
module.exports=R.m(24378).exports
