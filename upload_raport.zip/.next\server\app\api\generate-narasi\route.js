var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/generate-narasi/route.js")
R.c("server/chunks/[externals]_next_dist_0arv.vj._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0pc.3bc.js")
R.c("server/chunks/_next-internal_server_app_api_generate-narasi_route_actions_0tly-z5.js")
R.m(62781)
module.exports=R.m(62781).exports
