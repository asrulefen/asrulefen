module.exports=[18622,(e,a,t)=>{a.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,a,t)=>{a.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,a,t)=>{a.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,a,t)=>{a.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,a,t)=>{a.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},24361,(e,a,t)=>{a.exports=e.x("util",()=>require("util"))},14747,(e,a,t)=>{a.exports=e.x("path",()=>require("path"))},93695,(e,a,t)=>{a.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},85148,(e,a,t)=>{a.exports=e.x("better-sqlite3-90e2652d1716b047",()=>require("better-sqlite3-90e2652d1716b047"))},43793,e=>{"use strict";var a=e.i(85148);let t=e.i(14747).default.join(process.cwd(),"raport.db"),r=e.g._db||new a.default(t,{verbose:console.log});if(r.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS siswa (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nama_lengkap TEXT NOT NULL,
    nama_panggilan TEXT,
    nisn TEXT,
    kelompok TEXT DEFAULT 'A',
    jenis_kelamin TEXT,
    tempat_lahir TEXT,
    tanggal_lahir TEXT,
    agama TEXT,
    anak_ke TEXT,
    nama_ayah TEXT,
    nama_ibu TEXT,
    pekerjaan_ayah TEXT,
    pekerjaan_ibu TEXT,
    alamat TEXT,
    telepon TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS pengaturan (
    key TEXT PRIMARY KEY,
    value TEXT
  );

  CREATE TABLE IF NOT EXISTS indikator (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kategori TEXT NOT NULL, -- AGAMA, JATI_DIRI, LITERASI, PROJEK
    deskripsi TEXT NOT NULL,
    urutan INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS raport (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    siswa_id INTEGER,
    semester TEXT NOT NULL, -- I / 2025-2026
    tinggi_badan TEXT,
    berat_badan TEXT,
    sakit TEXT DEFAULT '0',
    izin TEXT DEFAULT '0',
    tanpa_keterangan TEXT DEFAULT '0',
    
    -- Teks Narasi AI
    teks_agama TEXT,
    teks_jati_diri TEXT,
    teks_literasi TEXT,
    teks_projek TEXT,
    refleksi_guru TEXT,

    -- Foto (Disimpan sebagai path lokal atau base64 jika kecil)
    foto_agama_1 TEXT, foto_agama_2 TEXT, foto_agama_3 TEXT,
    foto_jati_diri_1 TEXT, foto_jati_diri_2 TEXT, foto_jati_diri_3 TEXT,
    foto_literasi_1 TEXT, foto_literasi_2 TEXT, foto_literasi_3 TEXT,
    foto_projek_1 TEXT, foto_projek_2 TEXT, foto_projek_3 TEXT,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(siswa_id) REFERENCES siswa(id)
  );

  CREATE TABLE IF NOT EXISTS nilai_indikator (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    raport_id INTEGER,
    indikator_id INTEGER,
    nilai TEXT, -- Belum Muncul, Muncul Sebagian Besar, Muncul, Berkembang Sangat Baik
    FOREIGN KEY(raport_id) REFERENCES raport(id) ON DELETE CASCADE,
    FOREIGN KEY(indikator_id) REFERENCES indikator(id)
  );
`),0===r.prepare("SELECT COUNT(*) as count FROM indikator").get().count){let e=r.prepare("INSERT INTO indikator (kategori, deskripsi, urutan) VALUES (?, ?, ?)"),a=[["AGAMA","Mengucap kalimat Thoyyibah",1],["AGAMA","Melaksanakan atau mempraktekkan ibadah sehari-hari (Praktek sholat dhuha)",2],["AGAMA","Berdoa sebelum dan sesudah melaksanakan kegiatan dengan tertib",3],["AGAMA","Mengembalikan benda yang tidak miliknya",4],["AGAMA","Mengucap permisi jika mau lewat",5],["JATI_DIRI","Melakukan permainan fisik dengan teratur",1],["JATI_DIRI","Menggunakan alat tulis atau memegang pensil dengan benar",2],["JATI_DIRI","Meniru gerakan senam fantasi",3],["JATI_DIRI","Berdiri dengan tumit, berdiri dengan satu kaki dengan seimbang",4],["JATI_DIRI","Sabar menunggu giliran",5],["JATI_DIRI","Mau ditinggal ibu tanpa menangis",6],["LITERASI","Melakukan 2-3 perintah sederhana",1],["LITERASI","Menyebut Kembali 3-4 kata yang baru didengarnya",2],["LITERASI","Menyebut dan menunjukkan benda-benda yang berbentuk geometri",3],["LITERASI","Menunjukkan urutan benda untuk bilangan 1-10",4],["LITERASI","Melukis dengan jari",5],["LITERASI","Menyebutkan benda di sekitar sesuai dengan fungsinya",6],["PROJEK","Mengenal lingkungan serta memupuk kepedulian terhadap alam",1],["PROJEK","Melakukan kegiatan praktik secara bergotong royong",2],["PROJEK","Menyiapkan bahan-bahan menanam biji jagung dengan sistem hidroponik",3],["PROJEK","Menunjukkan antusiasme yang luar biasa dan mengisi media tanam dengan rapi",4],["PROJEK","Tekun memasukkan benih dan bertanggung jawab menyiram tanaman",5],["PROJEK","Menceritakan perubahan jagung dari tunas hingga tumbuh daun",6]];r.transaction(()=>{for(let t of a)e.run(t[0],t[1],t[2])})()}r.prepare("SELECT value FROM pengaturan WHERE key = 'gemini_api_key'").get()||r.prepare("INSERT INTO pengaturan (key, value) VALUES ('gemini_api_key', 'AIzaSyBdyaDHSyeiVtW0DC69TOPwDK58IF8HomU')").run();let n=(e,a,t)=>{try{r.exec(`ALTER TABLE ${e} ADD COLUMN ${a} TEXT DEFAULT '${t}'`)}catch(e){}};n("siswa","desa",""),n("siswa","kecamatan",""),n("siswa","kabupaten","Tuban"),n("siswa","provinsi","Jawa Timur"),n("siswa","nipd",""),n("siswa","user_id","1"),n("indikator","user_id","1"),e.s(["default",0,r])},54799,(e,a,t)=>{a.exports=e.x("crypto",()=>require("crypto"))},50088,e=>{"use strict";var a=e.i(47909),t=e.i(74017),r=e.i(96250),n=e.i(59756),i=e.i(61916),s=e.i(74677),o=e.i(69741),u=e.i(16795),d=e.i(87718),l=e.i(95169),E=e.i(47587),T=e.i(66012),p=e.i(70101),c=e.i(26937),R=e.i(10372),g=e.i(93695);e.i(52474);var k=e.i(220),A=e.i(89171),m=e.i(43793),I=e.i(23667);async function h(){try{let e=await (0,I.getServerSession)();if(!e?.user?.email)return A.NextResponse.json({error:"Unauthorized"},{status:401});let a=m.default.prepare("SELECT id FROM users WHERE email = ?").get(e.user.email);if(!a)return A.NextResponse.json({error:"Unauthorized"},{status:401});let t=m.default.prepare('SELECT * FROM indikator WHERE user_id = ? OR user_id = "1" ORDER BY kategori ASC, urutan ASC').all(a.id);return A.NextResponse.json(t)}catch(e){return A.NextResponse.json({error:"Failed to fetch indikator"},{status:500})}}async function _(e){try{let a=await (0,I.getServerSession)();if(!a?.user?.email)return A.NextResponse.json({error:"Unauthorized"},{status:401});let t=m.default.prepare("SELECT id FROM users WHERE email = ?").get(a.user.email);if(!t)return A.NextResponse.json({error:"Unauthorized"},{status:401});let r=await e.json();r.user_id=t.id;let n=m.default.prepare("INSERT INTO indikator (kategori, deskripsi, urutan, user_id) VALUES (@kategori, @deskripsi, @urutan, @user_id)").run(r);return A.NextResponse.json({id:n.lastInsertRowid})}catch(e){return A.NextResponse.json({error:"Failed to create indikator"},{status:500})}}e.s(["GET",0,h,"POST",0,_],70084);var N=e.i(70084);let x=new a.AppRouteRouteModule({definition:{kind:t.RouteKind.APP_ROUTE,page:"/api/indikator/route",pathname:"/api/indikator",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/src/app/api/indikator/route.ts",nextConfigOutput:"standalone",userland:N,...{}}),{workAsyncStorage:b,workUnitAsyncStorage:f,serverHooks:S}=x;async function M(e,a,r){r.requestMeta&&(0,n.setRequestMeta)(e,r.requestMeta),x.isDev&&(0,n.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let A="/api/indikator/route";A=A.replace(/\/index$/,"")||"/";let m=await x.prepare(e,a,{srcPage:A,multiZoneDraftMode:!1});if(!m)return a.statusCode=400,a.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:I,deploymentId:h,params:_,nextConfig:N,parsedUrl:b,isDraftMode:f,prerenderManifest:S,routerServerContext:M,isOnDemandRevalidate:v,revalidateOnlyGenerated:y,resolvedPathname:C,clientReferenceManifest:w,serverActionsManifest:O}=m,X=(0,o.normalizeAppPath)(A),L=!!(S.dynamicRoutes[X]||S.routes[C]),U=async()=>((null==M?void 0:M.render404)?await M.render404(e,a,b,!1):a.end("This page could not be found"),null);if(L&&!f){let e=!!S.routes[C],a=S.dynamicRoutes[X];if(a&&!1===a.fallback&&!e){if(N.adapterPath)return await U();throw new g.NoFallbackError}}let j=null;!L||x.isDev||f||(j="/index"===(j=C)?"/":j);let P=!0===x.isDev||!L,D=L&&!P;O&&w&&(0,s.setManifestsSingleton)({page:A,clientReferenceManifest:w,serverActionsManifest:O});let F=e.method||"GET",q=(0,i.getTracer)(),K=q.getActiveScopeSpan(),H=!!(null==M?void 0:M.isWrappedByNextServer),G=!!(0,n.getRequestMeta)(e,"minimalMode"),B=(0,n.getRequestMeta)(e,"incrementalCache")||await x.getIncrementalCache(e,N,S,G);null==B||B.resetRequestCache(),globalThis.__incrementalCache=B;let Y={params:_,previewProps:S.preview,renderOpts:{experimental:{authInterrupts:!!N.experimental.authInterrupts},cacheComponents:!!N.cacheComponents,supportsDynamicResponse:P,incrementalCache:B,cacheLifeProfiles:N.cacheLife,waitUntil:r.waitUntil,onClose:e=>{a.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(a,t,r,n)=>x.onRequestError(e,a,r,n,M)},sharedContext:{buildId:I,deploymentId:h}},J=new u.NodeNextRequest(e),$=new u.NodeNextResponse(a),W=d.NextRequestAdapter.fromNodeNextRequest(J,(0,d.signalFromNodeResponse)(a));try{let n,s=async e=>x.handle(W,Y).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":a.statusCode,"next.rsc":!1});let t=q.getRootSpanAttributes();if(!t)return;if(t.get("next.span_type")!==l.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${t.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=t.get("next.route");if(r){let a=`${F} ${r}`;e.setAttributes({"next.route":r,"http.route":r,"next.span_name":a}),e.updateName(a),n&&n!==e&&(n.setAttribute("http.route",r),n.updateName(a))}else e.updateName(`${F} ${A}`)}),o=async n=>{var i,o;let u=async({previousCacheEntry:t})=>{try{if(!G&&v&&y&&!t)return a.statusCode=404,a.setHeader("x-nextjs-cache","REVALIDATED"),a.end("This page could not be found"),null;let i=await s(n);e.fetchMetrics=Y.renderOpts.fetchMetrics;let o=Y.renderOpts.pendingWaitUntil;o&&r.waitUntil&&(r.waitUntil(o),o=void 0);let u=Y.renderOpts.collectedTags;if(!L)return await (0,T.sendResponse)(J,$,i,Y.renderOpts.pendingWaitUntil),null;{let e=await i.blob(),a=(0,p.toNodeOutgoingHttpHeaders)(i.headers);u&&(a[R.NEXT_CACHE_TAGS_HEADER]=u),!a["content-type"]&&e.type&&(a["content-type"]=e.type);let t=void 0!==Y.renderOpts.collectedRevalidate&&!(Y.renderOpts.collectedRevalidate>=R.INFINITE_CACHE)&&Y.renderOpts.collectedRevalidate,r=void 0===Y.renderOpts.collectedExpire||Y.renderOpts.collectedExpire>=R.INFINITE_CACHE?void 0:Y.renderOpts.collectedExpire;return{value:{kind:k.CachedRouteKind.APP_ROUTE,status:i.status,body:Buffer.from(await e.arrayBuffer()),headers:a},cacheControl:{revalidate:t,expire:r}}}}catch(a){throw(null==t?void 0:t.isStale)&&await x.onRequestError(e,a,{routerKind:"App Router",routePath:A,routeType:"route",revalidateReason:(0,E.getRevalidateReason)({isStaticGeneration:D,isOnDemandRevalidate:v})},!1,M),a}},d=await x.handleResponse({req:e,nextConfig:N,cacheKey:j,routeKind:t.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:S,isRoutePPREnabled:!1,isOnDemandRevalidate:v,revalidateOnlyGenerated:y,responseGenerator:u,waitUntil:r.waitUntil,isMinimalMode:G});if(!L)return null;if((null==d||null==(i=d.value)?void 0:i.kind)!==k.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==d||null==(o=d.value)?void 0:o.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});G||a.setHeader("x-nextjs-cache",v?"REVALIDATED":d.isMiss?"MISS":d.isStale?"STALE":"HIT"),f&&a.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let l=(0,p.fromNodeOutgoingHttpHeaders)(d.value.headers);return G&&L||l.delete(R.NEXT_CACHE_TAGS_HEADER),!d.cacheControl||a.getHeader("Cache-Control")||l.get("Cache-Control")||l.set("Cache-Control",(0,c.getCacheControlHeader)(d.cacheControl)),await (0,T.sendResponse)(J,$,new Response(d.value.body,{headers:l,status:d.value.status||200})),null};H&&K?await o(K):(n=q.getActiveScopeSpan(),await q.withPropagatedContext(e.headers,()=>q.trace(l.BaseServerSpan.handleRequest,{spanName:`${F} ${A}`,kind:i.SpanKind.SERVER,attributes:{"http.method":F,"http.target":e.url}},o),void 0,!H))}catch(a){if(a instanceof g.NoFallbackError||await x.onRequestError(e,a,{routerKind:"App Router",routePath:X,routeType:"route",revalidateReason:(0,E.getRevalidateReason)({isStaticGeneration:D,isOnDemandRevalidate:v})},!1,M),L)throw a;return await (0,T.sendResponse)(J,$,new Response(null,{status:500})),null}}e.s(["handler",0,M,"patchFetch",0,function(){return(0,r.patchFetch)({workAsyncStorage:b,workUnitAsyncStorage:f})},"routeModule",0,x,"serverHooks",0,S,"workAsyncStorage",0,b,"workUnitAsyncStorage",0,f],50088)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__11..8zh._.js.map