globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/ubxh6GmhCg8jh_X502zt-/_buildManifest.js",
    "static/ubxh6GmhCg8jh_X502zt-/_ssgManifest.js",
    "static/ubxh6GmhCg8jh_X502zt-/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0bzupvr5gt3k9.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/07lhk_q6pmm3r.js",
    "static/chunks/02g3221oh~3le.js",
    "static/chunks/turbopack-0l.eg18p.4nbp.js"
  ]
};
