module.exports=[18622,(e,t,a)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},24361,(e,t,a)=>{t.exports=e.x("util",()=>require("util"))},14747,(e,t,a)=>{t.exports=e.x("path",()=>require("path"))},93695,(e,t,a)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},85148,(e,t,a)=>{t.exports=e.x("better-sqlite3-90e2652d1716b047",()=>require("better-sqlite3-90e2652d1716b047"))},43793,e=>{"use strict";var t=e.i(85148);let a=e.i(14747).default.join(process.cwd(),"raport.db"),r=e.g._db||new t.default(a,{verbose:console.log});if(r.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS siswa (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nama_lengkap TEXT NOT NULL,
    nama_panggilan TEXT,
    nisn TEXT,
    kelompok TEXT DEFAULT 'A',
    jenis_kelamin TEXT,
    tempat_lahir TEXT,
    tanggal_lahir TEXT,
    agama TEXT,
    anak_ke TEXT,
    nama_ayah TEXT,
    nama_ibu TEXT,
    pekerjaan_ayah TEXT,
    pekerjaan_ibu TEXT,
    alamat TEXT,
    telepon TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS pengaturan (
    key TEXT PRIMARY KEY,
    value TEXT
  );

  CREATE TABLE IF NOT EXISTS indikator (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kategori TEXT NOT NULL, -- AGAMA, JATI_DIRI, LITERASI, PROJEK
    deskripsi TEXT NOT NULL,
    urutan INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS raport (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    siswa_id INTEGER,
    semester TEXT NOT NULL, -- I / 2025-2026
    tinggi_badan TEXT,
    berat_badan TEXT,
    sakit TEXT DEFAULT '0',
    izin TEXT DEFAULT '0',
    tanpa_keterangan TEXT DEFAULT '0',
    
    -- Teks Narasi AI
    teks_agama TEXT,
    teks_jati_diri TEXT,
    teks_literasi TEXT,
    teks_projek TEXT,
    refleksi_guru TEXT,

    -- Foto (Disimpan sebagai path lokal atau base64 jika kecil)
    foto_agama_1 TEXT, foto_agama_2 TEXT, foto_agama_3 TEXT,
    foto_jati_diri_1 TEXT, foto_jati_diri_2 TEXT, foto_jati_diri_3 TEXT,
    foto_literasi_1 TEXT, foto_literasi_2 TEXT, foto_literasi_3 TEXT,
    foto_projek_1 TEXT, foto_projek_2 TEXT, foto_projek_3 TEXT,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(siswa_id) REFERENCES siswa(id)
  );

  CREATE TABLE IF NOT EXISTS nilai_indikator (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    raport_id INTEGER,
    indikator_id INTEGER,
    nilai TEXT, -- Belum Muncul, Muncul Sebagian Besar, Muncul, Berkembang Sangat Baik
    FOREIGN KEY(raport_id) REFERENCES raport(id) ON DELETE CASCADE,
    FOREIGN KEY(indikator_id) REFERENCES indikator(id)
  );
`),0===r.prepare("SELECT COUNT(*) as count FROM indikator").get().count){let e=r.prepare("INSERT INTO indikator (kategori, deskripsi, urutan) VALUES (?, ?, ?)"),t=[["AGAMA","Mengucap kalimat Thoyyibah",1],["AGAMA","Melaksanakan atau mempraktekkan ibadah sehari-hari (Praktek sholat dhuha)",2],["AGAMA","Berdoa sebelum dan sesudah melaksanakan kegiatan dengan tertib",3],["AGAMA","Mengembalikan benda yang tidak miliknya",4],["AGAMA","Mengucap permisi jika mau lewat",5],["JATI_DIRI","Melakukan permainan fisik dengan teratur",1],["JATI_DIRI","Menggunakan alat tulis atau memegang pensil dengan benar",2],["JATI_DIRI","Meniru gerakan senam fantasi",3],["JATI_DIRI","Berdiri dengan tumit, berdiri dengan satu kaki dengan seimbang",4],["JATI_DIRI","Sabar menunggu giliran",5],["JATI_DIRI","Mau ditinggal ibu tanpa menangis",6],["LITERASI","Melakukan 2-3 perintah sederhana",1],["LITERASI","Menyebut Kembali 3-4 kata yang baru didengarnya",2],["LITERASI","Menyebut dan menunjukkan benda-benda yang berbentuk geometri",3],["LITERASI","Menunjukkan urutan benda untuk bilangan 1-10",4],["LITERASI","Melukis dengan jari",5],["LITERASI","Menyebutkan benda di sekitar sesuai dengan fungsinya",6],["PROJEK","Mengenal lingkungan serta memupuk kepedulian terhadap alam",1],["PROJEK","Melakukan kegiatan praktik secara bergotong royong",2],["PROJEK","Menyiapkan bahan-bahan menanam biji jagung dengan sistem hidroponik",3],["PROJEK","Menunjukkan antusiasme yang luar biasa dan mengisi media tanam dengan rapi",4],["PROJEK","Tekun memasukkan benih dan bertanggung jawab menyiram tanaman",5],["PROJEK","Menceritakan perubahan jagung dari tunas hingga tumbuh daun",6]];r.transaction(()=>{for(let a of t)e.run(a[0],a[1],a[2])})()}r.prepare("SELECT value FROM pengaturan WHERE key = 'gemini_api_key'").get()||r.prepare("INSERT INTO pengaturan (key, value) VALUES ('gemini_api_key', 'AIzaSyBdyaDHSyeiVtW0DC69TOPwDK58IF8HomU')").run();let n=(e,t,a)=>{try{r.exec(`ALTER TABLE ${e} ADD COLUMN ${t} TEXT DEFAULT '${a}'`)}catch(e){}};n("siswa","desa",""),n("siswa","kecamatan",""),n("siswa","kabupaten","Tuban"),n("siswa","provinsi","Jawa Timur"),n("siswa","nipd",""),n("siswa","user_id","1"),n("indikator","user_id","1"),e.s(["default",0,r])},54799,(e,t,a)=>{t.exports=e.x("crypto",()=>require("crypto"))},16020,(e,t,a)=>{"use strict";Object.defineProperty(a,"__esModule",{value:!0})},57660,(e,t,a)=>{"use strict";Object.defineProperty(a,"__esModule",{value:!0});var r={};Object.defineProperty(a,"default",{enumerable:!0,get:function(){return i.default}});var n=e.r(16020);Object.keys(n).forEach(function(e){"default"===e||"__esModule"===e||Object.prototype.hasOwnProperty.call(r,e)||e in a&&a[e]===n[e]||Object.defineProperty(a,e,{enumerable:!0,get:function(){return n[e]}})});var i=function(e){if(e&&e.__esModule)return e;if(null===e||"object"!=typeof e&&"function"!=typeof e)return{default:e};var t=s(void 0);if(t&&t.has(e))return t.get(e);var a={__proto__:null},r=Object.defineProperty&&Object.getOwnPropertyDescriptor;for(var n in e)if("default"!==n&&({}).hasOwnProperty.call(e,n)){var i=r?Object.getOwnPropertyDescriptor(e,n):null;i&&(i.get||i.set)?Object.defineProperty(a,n,i):a[n]=e[n]}return a.default=e,t&&t.set(e,a),a}(e.r(23667));function s(e){if("function"!=typeof WeakMap)return null;var t=new WeakMap,a=new WeakMap;return(s=function(e){return e?a:t})(e)}Object.keys(i).forEach(function(e){"default"===e||"__esModule"===e||Object.prototype.hasOwnProperty.call(r,e)||e in a&&a[e]===i[e]||Object.defineProperty(a,e,{enumerable:!0,get:function(){return i[e]}})})},99873,(e,t,a)=>{"use strict";Object.defineProperty(a,"__esModule",{value:!0}),a.default=function(e){return{id:"credentials",name:"Credentials",type:"credentials",credentials:{},authorize:()=>null,options:e}}},3413,e=>{"use strict";var t=e.i(47909),a=e.i(74017),r=e.i(96250),n=e.i(59756),i=e.i(61916),s=e.i(74677),o=e.i(69741),u=e.i(16795),l=e.i(87718),d=e.i(95169),p=e.i(47587),T=e.i(66012),E=e.i(70101),c=e.i(26937),g=e.i(10372),R=e.i(93695);e.i(52474);var k=e.i(220),m=e.i(57660),h=e.i(99873),A=e.i(49632),_=e.i(43793);let f=(0,m.default)({providers:[(0,h.default)({name:"Email & Password",credentials:{email:{label:"Email",type:"email",placeholder:"guru@tk.com"},password:{label:"Password",type:"password"}},async authorize(e){if(!e?.email||!e?.password)return null;let t=_.default.prepare("SELECT * FROM users WHERE email = ?").get(e.email);return t&&await A.default.compare(e.password,t.password)?{id:t.id.toString(),email:t.email,name:t.name}:null}})],session:{strategy:"jwt",maxAge:2592e3},callbacks:{jwt:async({token:e,user:t})=>(t&&(e.id=t.id),e),session:async({session:e,token:t})=>(e.user&&t.id&&(e.user.id=t.id),e)},pages:{signIn:"/login"},secret:process.env.NEXTAUTH_SECRET});e.s(["GET",0,f,"POST",0,f],27157);var I=e.i(27157);let b=new t.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/auth/[...nextauth]/route",pathname:"/api/auth/[...nextauth]",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/src/app/api/auth/[...nextauth]/route.ts",nextConfigOutput:"standalone",userland:I,...{}}),{workAsyncStorage:y,workUnitAsyncStorage:N,serverHooks:x}=b;async function v(e,t,r){r.requestMeta&&(0,n.setRequestMeta)(e,r.requestMeta),b.isDev&&(0,n.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let m="/api/auth/[...nextauth]/route";m=m.replace(/\/index$/,"")||"/";let h=await b.prepare(e,t,{srcPage:m,multiZoneDraftMode:!1});if(!h)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:A,deploymentId:_,params:f,nextConfig:I,parsedUrl:y,isDraftMode:N,prerenderManifest:x,routerServerContext:v,isOnDemandRevalidate:O,revalidateOnlyGenerated:w,resolvedPathname:M,clientReferenceManifest:C,serverActionsManifest:S}=h,P=(0,o.normalizeAppPath)(m),X=!!(x.dynamicRoutes[P]||x.routes[M]),j=async()=>((null==v?void 0:v.render404)?await v.render404(e,t,y,!1):t.end("This page could not be found"),null);if(X&&!N){let e=!!x.routes[M],t=x.dynamicRoutes[P];if(t&&!1===t.fallback&&!e){if(I.adapterPath)return await j();throw new R.NoFallbackError}}let L=null;!X||b.isDev||N||(L="/index"===(L=M)?"/":L);let U=!0===b.isDev||!X,D=X&&!U;S&&C&&(0,s.setManifestsSingleton)({page:m,clientReferenceManifest:C,serverActionsManifest:S});let F=e.method||"GET",q=(0,i.getTracer)(),K=q.getActiveScopeSpan(),G=!!(null==v?void 0:v.isWrappedByNextServer),H=!!(0,n.getRequestMeta)(e,"minimalMode"),B=(0,n.getRequestMeta)(e,"incrementalCache")||await b.getIncrementalCache(e,I,x,H);null==B||B.resetRequestCache(),globalThis.__incrementalCache=B;let J={params:f,previewProps:x.preview,renderOpts:{experimental:{authInterrupts:!!I.experimental.authInterrupts},cacheComponents:!!I.cacheComponents,supportsDynamicResponse:U,incrementalCache:B,cacheLifeProfiles:I.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,a,r,n)=>b.onRequestError(e,t,r,n,v)},sharedContext:{buildId:A,deploymentId:_}},Y=new u.NodeNextRequest(e),$=new u.NodeNextResponse(t),W=l.NextRequestAdapter.fromNodeNextRequest(Y,(0,l.signalFromNodeResponse)(t));try{let n,s=async e=>b.handle(W,J).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let a=q.getRootSpanAttributes();if(!a)return;if(a.get("next.span_type")!==d.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${a.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=a.get("next.route");if(r){let t=`${F} ${r}`;e.setAttributes({"next.route":r,"http.route":r,"next.span_name":t}),e.updateName(t),n&&n!==e&&(n.setAttribute("http.route",r),n.updateName(t))}else e.updateName(`${F} ${m}`)}),o=async n=>{var i,o;let u=async({previousCacheEntry:a})=>{try{if(!H&&O&&w&&!a)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let i=await s(n);e.fetchMetrics=J.renderOpts.fetchMetrics;let o=J.renderOpts.pendingWaitUntil;o&&r.waitUntil&&(r.waitUntil(o),o=void 0);let u=J.renderOpts.collectedTags;if(!X)return await (0,T.sendResponse)(Y,$,i,J.renderOpts.pendingWaitUntil),null;{let e=await i.blob(),t=(0,E.toNodeOutgoingHttpHeaders)(i.headers);u&&(t[g.NEXT_CACHE_TAGS_HEADER]=u),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let a=void 0!==J.renderOpts.collectedRevalidate&&!(J.renderOpts.collectedRevalidate>=g.INFINITE_CACHE)&&J.renderOpts.collectedRevalidate,r=void 0===J.renderOpts.collectedExpire||J.renderOpts.collectedExpire>=g.INFINITE_CACHE?void 0:J.renderOpts.collectedExpire;return{value:{kind:k.CachedRouteKind.APP_ROUTE,status:i.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:a,expire:r}}}}catch(t){throw(null==a?void 0:a.isStale)&&await b.onRequestError(e,t,{routerKind:"App Router",routePath:m,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:D,isOnDemandRevalidate:O})},!1,v),t}},l=await b.handleResponse({req:e,nextConfig:I,cacheKey:L,routeKind:a.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:x,isRoutePPREnabled:!1,isOnDemandRevalidate:O,revalidateOnlyGenerated:w,responseGenerator:u,waitUntil:r.waitUntil,isMinimalMode:H});if(!X)return null;if((null==l||null==(i=l.value)?void 0:i.kind)!==k.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(o=l.value)?void 0:o.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});H||t.setHeader("x-nextjs-cache",O?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),N&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let d=(0,E.fromNodeOutgoingHttpHeaders)(l.value.headers);return H&&X||d.delete(g.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||t.getHeader("Cache-Control")||d.get("Cache-Control")||d.set("Cache-Control",(0,c.getCacheControlHeader)(l.cacheControl)),await (0,T.sendResponse)(Y,$,new Response(l.value.body,{headers:d,status:l.value.status||200})),null};G&&K?await o(K):(n=q.getActiveScopeSpan(),await q.withPropagatedContext(e.headers,()=>q.trace(d.BaseServerSpan.handleRequest,{spanName:`${F} ${m}`,kind:i.SpanKind.SERVER,attributes:{"http.method":F,"http.target":e.url}},o),void 0,!G))}catch(t){if(t instanceof R.NoFallbackError||await b.onRequestError(e,t,{routerKind:"App Router",routePath:P,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:D,isOnDemandRevalidate:O})},!1,v),X)throw t;return await (0,T.sendResponse)(Y,$,new Response(null,{status:500})),null}}e.s(["handler",0,v,"patchFetch",0,function(){return(0,r.patchFetch)({workAsyncStorage:y,workUnitAsyncStorage:N})},"routeModule",0,b,"serverHooks",0,x,"workAsyncStorage",0,y,"workUnitAsyncStorage",0,N],3413)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0xfesnn._.js.map