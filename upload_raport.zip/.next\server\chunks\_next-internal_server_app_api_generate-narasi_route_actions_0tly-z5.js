module.exports=[94966,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_generate-narasi_route_actions_0tly-z5.js.map